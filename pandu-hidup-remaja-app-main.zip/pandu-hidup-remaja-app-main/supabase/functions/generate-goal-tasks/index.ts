import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { goalTitle, goalDescription, goalId } = await req.json()
    
    // Get Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from JWT
    const authHeader = req.headers.get('Authorization')!
    const token = authHeader.replace('Bearer ', '')
    const { data: { user } } = await supabaseClient.auth.getUser(token)

    if (!user) {
      throw new Error('User not authenticated')
    }

    // Get user profile for context
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single()

    let aiTasks = []

    // Try to use ChatGPT for more intelligent task generation
    try {
      const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
        method: 'POST',
        headers: {
          'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          model: 'gpt-3.5-turbo',
          messages: [
            {
              role: 'system',
              content: `Kamu adalah AI assistant untuk aplikasi LifeGuide yang membantu remaja Indonesia membuat rencana untuk mencapai goal mereka.

Tugas kamu:
1. Buat 5-7 task yang spesifik, actionable, dan realistis untuk goal yang diberikan
2. Urutkan task dari yang paling mudah/foundational ke yang lebih advanced
3. Berikan timeline yang masuk akal (1-30 hari dari sekarang)
4. Sesuaikan dengan konteks remaja Indonesia

Format response dalam JSON:
{
  "tasks": [
    {
      "title": "Judul task yang jelas dan actionable",
      "description": "Deskripsi detail bagaimana melakukan task ini",
      "due_date": "YYYY-MM-DD",
      "difficulty": "easy|medium|hard",
      "estimated_time": "30 menit - 2 jam"
    }
  ]
}

Konteks pengguna:
- Tingkat sekolah: ${profile?.school_level || 'SMA'}
- Umur: ${profile?.age || '17'} tahun`
            },
            {
              role: 'user',
              content: `Goal: ${goalTitle}
Deskripsi: ${goalDescription || 'Tidak ada deskripsi tambahan'}

Buatkan breakdown task yang detail dan realistis untuk goal ini.`
            }
          ],
          max_tokens: 1000,
          temperature: 0.7,
        }),
      })

      if (openaiResponse.ok) {
        const openaiData = await openaiResponse.json()
        const aiContent = openaiData.choices[0].message.content
        
        // Try to parse JSON response
        try {
          const parsedResponse = JSON.parse(aiContent)
          if (parsedResponse.tasks && Array.isArray(parsedResponse.tasks)) {
            aiTasks = parsedResponse.tasks.map((task: any, index: number) => ({
              title: task.title,
              description: task.description,
              due_date: task.due_date || getDateFromNow(index + 1),
              difficulty: task.difficulty || 'medium',
              estimated_time: task.estimated_time || '1 jam'
            }))
          }
        } catch (parseError) {
          console.log('Failed to parse AI response, using fallback')
        }
      }
    } catch (openaiError) {
      console.log('OpenAI request failed, using fallback task generation')
    }

    // Fallback to rule-based task generation if AI fails
    if (aiTasks.length === 0) {
      aiTasks = generateTasksForGoal(goalTitle, goalDescription)
    }

    // Insert tasks into database
    const tasksToInsert = aiTasks.map(task => ({
      goal_id: goalId,
      user_id: user.id,
      title: task.title,
      description: task.description,
      due_date: task.due_date
    }))

    const { error } = await supabaseClient
      .from('tasks')
      .insert(tasksToInsert)

    if (error) throw error

    return new Response(
      JSON.stringify({ success: true, tasks: aiTasks }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Generate tasks error:', error)
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 400 }
    )
  }
})

function getDateFromNow(days: number): string {
  const date = new Date()
  date.setDate(date.getDate() + days)
  return date.toISOString().split('T')[0]
}

function generateTasksForGoal(goalTitle: string, goalDescription: string = '') {
  const baseDate = new Date()
  const goal = (goalTitle + ' ' + goalDescription).toLowerCase()
  
  // Enhanced rule-based task generation
  if (goal.includes('itb') || goal.includes('universitas') || goal.includes('kuliah')) {
    return [
      {
        title: 'Riset jurusan dan universitas target',
        description: 'Cari tahu persyaratan masuk, passing grade, dan kurikulum program studi yang diminati',
        due_date: getDateFromNow(1),
        difficulty: 'easy',
        estimated_time: '2 jam'
      },
      {
        title: 'Buat jadwal belajar harian',
        description: 'Susun jadwal belajar yang konsisten dengan alokasi waktu untuk setiap mata pelajaran UTBK',
        due_date: getDateFromNow(2),
        difficulty: 'medium',
        estimated_time: '1 jam'
      },
      {
        title: 'Latihan soal matematika dasar',
        description: 'Kerjakan 20 soal matematika dasar setiap hari untuk memperkuat fondasi',
        due_date: getDateFromNow(3),
        difficulty: 'medium',
        estimated_time: '1.5 jam'
      },
      {
        title: 'Belajar bahasa Indonesia dan bahasa Inggris',
        description: 'Fokus pada pemahaman bacaan dan tata bahasa untuk TPS',
        due_date: getDateFromNow(5),
        difficulty: 'medium',
        estimated_time: '1 jam'
      },
      {
        title: 'Try out UTBK pertama',
        description: 'Ikuti try out online atau offline untuk mengukur kemampuan awal',
        due_date: getDateFromNow(7),
        difficulty: 'hard',
        estimated_time: '3 jam'
      },
      {
        title: 'Evaluasi hasil try out',
        description: 'Analisis hasil try out dan identifikasi materi yang perlu diperbaiki',
        due_date: getDateFromNow(8),
        difficulty: 'medium',
        estimated_time: '1 jam'
      }
    ]
  } else if (goal.includes('bahasa inggris') || goal.includes('english')) {
    return [
      {
        title: 'Tes level bahasa Inggris saat ini',
        description: 'Ikuti tes online untuk mengetahui level CEFR kamu (A1, A2, B1, B2, C1, C2)',
        due_date: getDateFromNow(1),
        difficulty: 'easy',
        estimated_time: '30 menit'
      },
      {
        title: 'Download aplikasi belajar bahasa',
        description: 'Install Duolingo, Busuu, atau aplikasi serupa untuk belajar rutin',
        due_date: getDateFromNow(1),
        difficulty: 'easy',
        estimated_time: '15 menit'
      },
      {
        title: 'Belajar 20 vocabulary baru setiap hari',
        description: 'Catat kata-kata baru dalam notebook dan buat kalimat contoh',
        due_date: getDateFromNow(2),
        difficulty: 'medium',
        estimated_time: '30 menit'
      },
      {
        title: 'Nonton film/series dengan subtitle Inggris',
        description: 'Mulai dengan subtitle Indonesia, lalu beralih ke subtitle Inggris',
        due_date: getDateFromNow(3),
        difficulty: 'medium',
        estimated_time: '1 jam'
      },
      {
        title: 'Praktek speaking 15 menit setiap hari',
        description: 'Rekam diri sendiri berbicara bahasa Inggris atau chat dengan AI',
        due_date: getDateFromNow(5),
        difficulty: 'hard',
        estimated_time: '15 menit'
      }
    ]
  } else if (goal.includes('programming') || goal.includes('coding') || goal.includes('python') || goal.includes('javascript')) {
    return [
      {
        title: 'Pilih bahasa pemrograman pertama',
        description: 'Tentukan mau belajar Python, JavaScript, atau bahasa lain sesuai tujuan',
        due_date: getDateFromNow(1),
        difficulty: 'easy',
        estimated_time: '30 menit'
      },
      {
        title: 'Setup development environment',
        description: 'Install code editor (VS Code) dan tools yang diperlukan',
        due_date: getDateFromNow(2),
        difficulty: 'medium',
        estimated_time: '1 jam'
      },
      {
        title: 'Belajar syntax dasar',
        description: 'Pelajari variabel, tipe data, dan operasi dasar',
        due_date: getDateFromNow(4),
        difficulty: 'medium',
        estimated_time: '2 jam'
      },
      {
        title: 'Buat program "Hello World"',
        description: 'Tulis dan jalankan program pertama kamu',
        due_date: getDateFromNow(5),
        difficulty: 'easy',
        estimated_time: '30 menit'
      },
      {
        title: 'Latihan problem solving',
        description: 'Kerjakan 5 soal programming sederhana di platform online',
        due_date: getDateFromNow(7),
        difficulty: 'hard',
        estimated_time: '2 jam'
      }
    ]
  } else {
    // Generic task breakdown
    return [
      {
        title: `Riset mendalam tentang ${goalTitle}`,
        description: 'Cari informasi lengkap, tutorial, dan sumber daya yang dibutuhkan untuk mencapai goal ini',
        due_date: getDateFromNow(1),
        difficulty: 'easy',
        estimated_time: '1 jam'
      },
      {
        title: `Buat rencana detail untuk ${goalTitle}`,
        description: 'Susun langkah-langkah konkret dengan timeline yang realistis',
        due_date: getDateFromNow(2),
        difficulty: 'medium',
        estimated_time: '1.5 jam'
      },
      {
        title: `Mulai langkah pertama`,
        description: 'Ambil tindakan nyata pertama menuju goal ini, sekecil apapun',
        due_date: getDateFromNow(3),
        difficulty: 'medium',
        estimated_time: '1 jam'
      },
      {
        title: `Evaluasi progress minggu pertama`,
        description: 'Tinjau apa yang sudah dicapai dan sesuaikan rencana jika perlu',
        due_date: getDateFromNow(7),
        difficulty: 'easy',
        estimated_time: '30 menit'
      },
      {
        title: `Cari mentor atau komunitas`,
        description: 'Bergabung dengan grup atau cari orang yang bisa memberikan guidance',
        due_date: getDateFromNow(10),
        difficulty: 'medium',
        estimated_time: '1 jam'
      }
    ]
  }
}