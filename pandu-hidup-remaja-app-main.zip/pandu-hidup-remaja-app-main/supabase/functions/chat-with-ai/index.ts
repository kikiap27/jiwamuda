import { serve } from "https://deno.land/std@0.168.0/http/server.ts"
import { createClient } from 'https://esm.sh/@supabase/supabase-js@2'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response('ok', { headers: corsHeaders })
  }

  try {
    const { message, conversationHistory = [] } = await req.json()
    
    // Get Supabase client
    const supabaseClient = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Get user from JWT
    const authHeader = req.headers.get('Authorization')!
    const token = authHeader.replace('Bearer ', '')
    const { data: { user } } = await supabaseClient.auth.getUser(token)

    if (!user) {
      throw new Error('User not authenticated')
    }

    // Get user profile for context
    const { data: profile } = await supabaseClient
      .from('profiles')
      .select('*')
      .eq('id', user.id)
      .single()

    // Get user goals for context
    const { data: goals } = await supabaseClient
      .from('goals')
      .select('*, tasks(*)')
      .eq('user_id', user.id)
      .eq('status', 'active')

    // Prepare context for ChatGPT
    const userContext = {
      name: profile?.full_name || 'Sobat',
      age: profile?.age,
      schoolLevel: profile?.school_level,
      activeGoals: goals?.length || 0,
      goalTitles: goals?.map(g => g.title) || []
    }

    // Call ChatGPT API
    const openaiResponse = await fetch('https://api.openai.com/v1/chat/completions', {
      method: 'POST',
      headers: {
        'Authorization': `Bearer ${Deno.env.get('OPENAI_API_KEY')}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        model: 'gpt-3.5-turbo',
        messages: [
          {
            role: 'system',
            content: `Kamu adalah asisten AI untuk aplikasi LifeGuide, aplikasi panduan hidup untuk remaja Indonesia. 

Konteks pengguna:
- Nama: ${userContext.name}
- Umur: ${userContext.age || 'tidak diketahui'}
- Tingkat sekolah: ${userContext.schoolLevel || 'tidak diketahui'}
- Goal aktif: ${userContext.activeGoals}
- Goal yang sedang dijalankan: ${userContext.goalTitles.join(', ') || 'belum ada'}

Peranmu:
1. Berikan motivasi dan dukungan untuk remaja Indonesia
2. Bantu dengan masalah belajar, karir, dan pengembangan diri
3. Gunakan bahasa Indonesia yang ramah dan mudah dipahami
4. Berikan saran praktis dan actionable
5. Jika ditanya tentang goal, berikan saran yang spesifik dan terukur
6. Selalu positif dan mendukung

Gaya komunikasi:
- Gunakan emoji yang sesuai
- Bahasa santai tapi informatif
- Berikan contoh konkret
- Jangan terlalu panjang (maksimal 3 paragraf)
- Fokus pada solusi praktis`
          },
          ...conversationHistory.slice(-5), // Keep last 5 messages for context
          {
            role: 'user',
            content: message
          }
        ],
        max_tokens: 500,
        temperature: 0.7,
      }),
    })

    if (!openaiResponse.ok) {
      throw new Error(`OpenAI API error: ${openaiResponse.status}`)
    }

    const openaiData = await openaiResponse.json()
    const aiResponse = openaiData.choices[0].message.content

    return new Response(
      JSON.stringify({ 
        success: true, 
        response: aiResponse,
        timestamp: new Date().toISOString()
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  } catch (error) {
    console.error('Chat AI Error:', error)
    
    // Fallback response if ChatGPT fails
    const fallbackResponse = generateFallbackResponse(message)
    
    return new Response(
      JSON.stringify({ 
        success: true, 
        response: fallbackResponse,
        fallback: true,
        timestamp: new Date().toISOString()
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )
  }
})

function generateFallbackResponse(message: string): string {
  const lowerMessage = message.toLowerCase()
  
  if (lowerMessage.includes('motivasi') || lowerMessage.includes('semangat')) {
    return "Aku percaya kamu pasti bisa! 💪 Setiap langkah kecil yang kamu ambil hari ini adalah investasi untuk masa depan yang lebih baik. Jangan menyerah, karena perjalanan menuju sukses memang tidak mudah, tapi hasilnya akan sepadan! ✨"
  } else if (lowerMessage.includes('belajar') || lowerMessage.includes('study')) {
    return "Tips belajar efektif: 📚 1) Gunakan teknik Pomodoro (25 menit fokus, 5 menit istirahat), 2) Buat catatan dengan mind mapping, 3) Ajari orang lain materi yang sudah kamu pelajari. Yang paling penting, konsisten dan jangan lupa istirahat ya! 😊"
  } else if (lowerMessage.includes('goal') || lowerMessage.includes('target')) {
    return "Untuk mencapai goal, coba break down jadi langkah-langkah kecil! 🎯 Buat timeline yang realistis, rayakan pencapaian kecil, dan jangan takut untuk adjust rencana kalau perlu. Yang penting tetap bergerak maju! 🚀"
  } else {
    return "Terima kasih sudah berbagi! 😊 Aku di sini untuk membantu kamu dengan apapun yang kamu butuhkan - mulai dari motivasi, tips belajar, sampai planning untuk masa depan. Ada yang spesifik yang ingin kamu tanyakan?"
  }
}